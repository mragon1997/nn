self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "14db0c7692cf5ed17195",
    "url": "//mragon1997.github.io/nn/css/main.d7bd635a.css"
  },
  {
    "revision": "9a5705b5d4999bf958942437c6ba87a0",
    "url": "//mragon1997.github.io/nn/img/1.9a5705b5.png"
  },
  {
    "revision": "47a3b47275262fe2f804c42b7ddab603",
    "url": "//mragon1997.github.io/nn/img/10.47a3b472.png"
  },
  {
    "revision": "daac23822b32e0a65ea6c9e0bd8e4c9a",
    "url": "//mragon1997.github.io/nn/img/12.daac2382.png"
  },
  {
    "revision": "5dce1fa800fe0c320b86be1d72272490",
    "url": "//mragon1997.github.io/nn/img/13.5dce1fa8.png"
  },
  {
    "revision": "143af105f77b6a1a48c50d759af98a72",
    "url": "//mragon1997.github.io/nn/img/2.143af105.png"
  },
  {
    "revision": "5fdc0a075716960ca5ccf2e04b0df89f",
    "url": "//mragon1997.github.io/nn/img/3.5fdc0a07.png"
  },
  {
    "revision": "3645b3ebd5e3e92928be8e8ce65a1525",
    "url": "//mragon1997.github.io/nn/img/4.3645b3eb.png"
  },
  {
    "revision": "c9817f7662bf791ab53f14c81ae3e682",
    "url": "//mragon1997.github.io/nn/index.html"
  },
  {
    "revision": "6fb161072b40720325bd",
    "url": "//mragon1997.github.io/nn/js/1.076e4518.chunk.js"
  },
  {
    "revision": "14db0c7692cf5ed17195",
    "url": "//mragon1997.github.io/nn/js/main.673a64c8.js"
  }
]);